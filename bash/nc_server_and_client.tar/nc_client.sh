#!/bin/bash
#
# netcat command client
#
# written by Reto Hasler (c) 2013 retohasler88@gmail.com 
#

SERVERIP=127.0.0.1
PORT=8080

echo "netcatclient startet"
echo ""
while true
do 
	read -s -n 1 COMMAND 
	echo "$COMMAND" | nc -c $SERVERIP $PORT > /dev/null
done