#!/bin/bash
#
# netcat command server
#
# written by Reto Hasler (c) 2013 retohasler88@gmail.com 
#

PORT=8080

echo "netcatserver started"
echo ""
while true
do 
	COMMAND=$(nc -lp $PORT)
	case $COMMAND in
		"w")
			echo "up";;
		"a")
			echo "left";;
		"s")
			echo "down";;
		"d")
			echo "right";;
		*)
			echo "invalid command: $COMMAND";;
	esac
done