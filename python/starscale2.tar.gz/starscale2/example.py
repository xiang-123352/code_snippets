#!/usr/bin/env python
# coding:utf-8

import gtk
from starscale2 import StarScale2

if __name__ == "__main__":        
    win = gtk.Window()
    win.resize(600,150)
    win.connect('delete-event', gtk.main_quit)
    
    
    vbox = gtk.VBox()
    win.add(vbox)
    
    vbox.pack_start(StarScale2(10,5, image_width=32), False, True)
    vbox.pack_start(StarScale2(5,5, half=True), False, True)
    vbox.pack_start(StarScale2(10,5, overlap=True), True, True)
    
    win.show_all()    
    gtk.main()
